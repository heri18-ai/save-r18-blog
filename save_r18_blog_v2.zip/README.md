# Save R18 - Blog Harian Saya

Ini adalah halaman web sederhana untuk promosi channel YouTube dan konten pribadi Save R18.

## Fitur Website
- Tombol Subscribe ke channel YouTube
- Deskripsi channel
- Link media sosial
- Kontak (email dan WhatsApp)
- Artikel blog

## Cara Menampilkan Website via GitHub Pages

1. **Buat Repositori Baru di GitHub**
   - Nama bisa seperti `save-r18-blog`
   
2. **Upload File HTML**
   - Upload file `index.html` ke repositori tersebut

3. **Aktifkan GitHub Pages**
   - Buka tab `Settings` > `Pages`
   - Di bagian "Source" pilih: `main` branch dan folder `/ (root)`
   - Klik "Save"

4. **Akses Website Kamu**
   - Setelah beberapa detik, kamu akan bisa akses website di alamat seperti:
     ```
     https://heri18-ai.github.io/save-r18-blog/
     ```

## Kontak
- Email: heri80sulistiyo@gmail.com
- WhatsApp: +6285290555118
